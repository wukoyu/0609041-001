// 檔名：main.js
import inquirer from "inquirer";
import { chat } from "./engine.js";

// 產生 session ID
const sessionId = "user_" + Date.now();
console.log("AI 客服 (輸入 exit 離開)\n");

while (true) {
  // 等待使用者輸入
  const answers = await inquirer.prompt([
    { type: "input", name: "message", message: "→ " },
  ]);
  const message = answers.message;

  // 離開
  if (message === "exit") break;

  // 空白就跳過
  if (!message.trim()) continue;

  // 送出訊息並顯示回覆
  const result = await chat(sessionId, message);
  console.log("[" + result.intent + "] " + result.response + "\n");
}
