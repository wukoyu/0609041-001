import { Type } from "@google/genai";

// 工具定義
const tools = [
  {
    functionDeclarations: [
      {
        name: "get_order_status",
        description: "查詢訂單狀態",
        parameters: {
          type: Type.OBJECT,
          properties: {
            order_id: { type: Type.STRING, description: "訂單編號" },
          },
          required: ["order_id"],
        },
      },
      {
        name: "track_shipping",
        description: "查詢物流狀態",
        parameters: {
          type: Type.OBJECT,
          properties: {
            order_id: { type: Type.STRING, description: "訂單編號" },
          },
          required: ["order_id"],
        },
      },
    ],
  },
];

// 假資料（實際專案會改成查資料庫）
const orders = {
  A12345: { status: "已出貨", total: 1280, items: ["藍牙耳機", "手機殼"] },
  A12346: { status: "處理中", total: 599, items: ["充電線"] },
};

const shipping = {
  A12345: { carrier: "黑貓宅急便", status: "配送中", eta: "明天下午" },
  A12346: { carrier: "尚未出貨", status: "等待出貨", eta: "-" },
};

// 執行工具
function executeFunction(name, args) {
  if (name === "get_order_status") {
    return orders[args.order_id] || { error: "找不到訂單" };
  }
  if (name === "track_shipping") {
    return shipping[args.order_id] || { error: "找不到物流資訊" };
  }
  return { error: "未知功能" };
}

export { tools, executeFunction };
