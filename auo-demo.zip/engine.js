import { ai } from "./lib/genai.js";
import { client } from "./lib/qdrant.js";
import { SessionManager } from "./session.js";
import { tools, executeFunction } from "./tools.js";

const SYSTEM_PROMPT =
  "你是電商平台的 AI 客服。使用台灣繁體中文，語氣親切，回答簡潔。";

async function classifyIntent(message) {
  const { text } = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `分類這個訊息的意圖：${message}`,
    config: {
      temperature: 0,
      responseMimeType: "application/json",
      responseSchema: {
        type: "object",
        properties: {
          intent: { type: "string", enum: ["ORDER", "HUMAN", "OTHER"] },
        },
        required: ["intent"],
      },
    },
  });
  return JSON.parse(text).intent;
}

// 訂單查詢（用 Function Calling）
async function handleOrder(message, history) {
  // 把最近 10 筆對話轉成 Gemini 需要的格式
  const recentHistory = history.slice(-10);
  const formattedHistory = recentHistory.map(function (h) {
    return {
      role: h.role,
      parts: [{ text: h.content }],
    };
  });

  const chat = ai.chats.create({
    model: "gemini-2.5-flash",
    config: { systemInstruction: SYSTEM_PROMPT, tools },
    history: formattedHistory,
  });

  const res = await chat.sendMessage({ message });

  // 如果沒有要呼叫函式，直接回傳文字
  if (!res.functionCalls || res.functionCalls.length === 0) {
    return res.text;
  }

  // 執行函式並準備回傳結果
  const results = [];
  for (const fc of res.functionCalls) {
    results.push({
      functionResponse: {
        name: fc.name,
        response: executeFunction(fc.name, fc.args),
      },
    });
  }

  // 把函式執行結果送回給 LLM
  const finalRes = await chat.sendMessage({ message: results });
  return finalRes.text;
}

// 一般問答（先查 FAQ，沒有就用 LLM 回答）
async function handleQuestion(message) {
  // 把使用者問題轉成向量
  const { embeddings } = await ai.models.embedContent({
    model: "gemini-embedding-001",
    contents: message,
    config: { taskType: "RETRIEVAL_QUERY" },
  });

  // 搜尋 FAQ
  const results = await client.search("faq", {
    vector: embeddings[0].values,
    limit: 3,
    with_payload: true,
  });

  // 過濾相似度太低的結果
  const docs = results.filter(function (r) {
    return r.score > 0.6;
  });

  // 組合參考資料
  let context = "";
  if (docs.length > 0) {
    const faqTexts = [];
    for (const d of docs) {
      faqTexts.push(`Q: ${d.payload.question}\nA: ${d.payload.answer}`);
    }
    context = faqTexts.join("\n\n");
  }

  // 準備 prompt
  let prompt = message;
  if (context) {
    prompt = `根據 FAQ 回答：\n\n${context}\n\n問題：${message}`;
  }

  // 產生回答
  const { text } = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: { systemInstruction: SYSTEM_PROMPT },
  });
  return text;
}

const sessions = new SessionManager();

async function chat(sessionId, message) {
  // 記錄使用者訊息
  sessions.add(sessionId, "user", message);

  // 判斷意圖
  const intent = await classifyIntent(message);
  const history = sessions.get(sessionId).history;

  // 根據意圖決定怎麼處理
  let response;
  if (intent === "HUMAN") {
    response = "好的，我為您轉接人工客服。\n客服專線：0800-123-456";
  } else if (intent === "ORDER") {
    response = await handleOrder(message, history);
  } else {
    response = await handleQuestion(message);
  }

  // 記錄回覆
  sessions.add(sessionId, "model", response);
  return { response, intent };
}

export { chat };
