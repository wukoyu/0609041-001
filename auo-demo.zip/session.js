class SessionManager {
  constructor() {
    this.sessions = new Map();
  }

  get(id) {
    if (!this.sessions.has(id)) {
      this.sessions.set(id, { history: [] });
    }
    return this.sessions.get(id);
  }

  add(id, role, content) {
    const s = this.get(id);
    s.history.push({ role, content });
    if (s.history.length > 50) s.history = s.history.slice(-40);
  }
}

export { SessionManager };
